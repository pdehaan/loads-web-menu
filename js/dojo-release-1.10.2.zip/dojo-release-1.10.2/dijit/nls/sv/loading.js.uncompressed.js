define(
"dijit/nls/sv/loading", ({
	loadingState: "Läser in...",
	errorState: "Det har inträffat ett fel."
})
);
